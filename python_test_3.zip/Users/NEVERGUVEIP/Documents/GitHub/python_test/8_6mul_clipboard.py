#！python3 
# -*- coding: utf-8 -*-
"""
Created on Sun Aug 12 09:50:15 2018

用一个关键字一段剪贴板文字

运行 py mcb.pyw save spam
当前剪贴板的内容用spam保存
通过运行 py mcb.pyw spam 
将文本加载到剪贴板
py mcb.pyw list 
将所有关键字的列表复制到剪贴板




@author: NEVERGUVEIP
"""



