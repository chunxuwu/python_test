# -*- coding: utf-8 -*-
"""
Created on Mon Aug  6 09:57:02 2018

@author: NEVERGUVEIP
"""

spam=['apple','bananas','tofu','cats']
for i in range(len(spam)-1):
    print(spam[i],end=',')
print('and '+spam[-1])